﻿namespace MauiAppEventos.Models
{
    public partial class EventosModels
    {
        
        public string Nome { get; set; }



     }
}
