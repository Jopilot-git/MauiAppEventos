namespace MauiAppEventos;

public partial class teste : ContentView
{
	public teste()
	{
		InitializeComponent();
	}
}